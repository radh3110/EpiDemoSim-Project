from strategy import *
from cost import *
from variables import *
from initialise import *
import xlrd
import numpy as np
from varassigning import *

#plottype = input("1.cumulative plots 2.instant plots. choice: ")

plottype = 1

readfrom = open("input.txt", "r+")

power[0] = int(readfrom.read(1))
readfrom.read(1)
power[1] = int(readfrom.read(1))
readfrom.read(1)
power[2] = int(readfrom.read(1))
readfrom.read(1)

sus[0] = float(readfrom.read(5))
sus[1] = float(readfrom.read(5))
sus[2] = float(readfrom.read(5))

delay[0] = float(readfrom.read(3))
delay[1] = float(readfrom.read(3))
delay[2] = float(readfrom.read(4))


for outer in range(0,3):
    for inner in range (0,length):
        costs[outer][inner] = float(readfrom.read(5))

for outer in range(0,3):
    for inner in range (0,length):
        prob[outer][inner] = float(readfrom.read(5))

readfrom.read(1)

varassigning()
#initialisation()
print "strategy - s0"
strat(plottype, 1)

for outer in range(0,3):
    for inner in range (0,length):
        prob[outer][inner] = float(readfrom.read(5))

print "strategy - s1"
strat(plottype,  2)

for outer in range(0,3):
    for inner in range (0,length):
        prob[outer][inner] = float(readfrom.read(5))


    #print prob, delay
print "strategy - s2"
strat(plottype,  3)

for outer in range(0, 3):
    for inner in range(0, length):
        prob[outer][inner] = float(readfrom.read(5))

print "strategy - s3"
strat(plottype,  4)

for outer in range(0, 3):
    for inner in range(0, length):
        prob[outer][inner] = float(readfrom.read(5))

print "strategy - s4"
strat(plottype, 5)

for outer in range(0, 3):
    for inner in range(0, length):
        prob[outer][inner] = float(readfrom.read(5))

print "strategy - s5"
strat(plottype, 6)

for outer in range(0, 3):
    for inner in range(0, length):
        prob[outer][inner] = float(readfrom.read(5))

readfrom.close()
print "strategy - s6"
strat(plottype, 7)


print "strategy - s7"
strat(plottype, 8)