
from variables import *
from initialise import *
from home_work_coordinates import *
from movingpeople import *
from infecting import *
from recovery import *
from gotohospi import *
from gotomarket import *
from suscep import *
from ploting import *
from cost import *
import random
import varassigning
from measures import *

def strat(plottype,  number):
    gf = 0
    gt = 0

    infectionresult = [[0 for x in range(totalTime)] for y in range(2)]
    recoveryresult = [[0 for x in range(totalTime)] for y in range(2)]
    infectedtemp = 0
    exposedtemp = 0
    recoveredtemp = 0
    removedtemp = 0
    peopletoHospi = [0 for x in range(totalTime)]
    peopleH = 0
    iterHospi = 0
    goingtoMarket = 0
    takencare = 0
    peopleinmarket = [0 for z in range((totalTime/24) + 1)]
    f = 0
    over = 0
    vaccinated = 0
    probabilitytomove = 0.5
    peak = 0
    peaktime = 0

    secondinitialisation(number)

    for j in range(0, totalTime):

        iterHospi= 0

        if j%24 == markethoursStop+1 :
            peopleinmarket[f] = goingtoMarket
            f += 1
            goingtoMarket = 0

        for i in range(0,people1+people2):
            if people[i][11] == people[i][0] and people[i][12] == people[i][1]:   #duration of exposure
               people[i][4] += 1
            else:
                people[i][4] = 0

            if people[i][9] > 0:
                coordinates[people[i][0]][people[i][1]][people[i][9]  - 1] += 1
                if j > 0 :
                    coordinates[people[i][11]][people[i][12]][people[i][9] - 1] -= 1
            people[i][11] = people[i][0]
            people[i][12] = people[i][1]

        infectionresult[0][j] = exposepeople(people, population)

        if (j % 24 >= activehoursStart) and (j % 24 <= activehoursStop) :
            if j % 24 == activehoursStart :
                for i in range(0, population):             #moving to workplace
                    if(people[i][15] != 1) and (people[i][15]!= -2) and people[i][3] != 5:
                        willStay = random.random()
                        if willStay < probabilitytoStay:   #to stay at home even if infected
                            people[i][0] = people[i][23]
                            people[i][1] = people[i][24]
                        else:
                            people[i][0] = people[i][21]
                            people[i][1] = people[i][22]
                    elif people[i][15] == 1:                #if infected don't go
                        willGo = random.random()
                        if willGo < probabilitytoHospi:    #with some probability go to hospital
                            people[i][0] = people[i][21]
                            people[i][1] = people[i][22]
                    elif people[i][3] == 5:
                        goingtoMarket += gotoMarket(i,j)

            elif (j % 24 > activehoursStart and j % 24 < activehoursStop):
                for i in range(0, people1+people2):  # finding possible slots to move
                    if (people[i][15] != 1) and (people[i][15] != -2) and people[i][3] != 5:
                        if random.random() < probabilitytomove:
                            move(i,people[i][2])
                    elif people[i][3] == 5:
                        goingtoMarket += gotoMarket(i,j)

                    elif people[i][15] == 1:
                        iterHospi += gotoHospi(people, i)
                peopletoHospi[j] = iterHospi

            elif (j % 24 == activehoursStop):
                for i in range(0, people1+people2):
                    if people[i][3] != 5:
                        people[i][0] = people[i][23]
                        people[i][1] = people[i][24]
                    elif people[i][3] == 5:
                        goingtoMarket += gotoMarket(i,j)

        elif (j % 24 == markethoursStart or  j% 24 == markethoursStart+1):
            for i in range(0, people1 + people2):
                goingtoMarket += gotoMarket(i,j)

        elif j % 24 == markethoursStop :
            for i in range(0, people1+people2):
                people[i][0] = people[i][23]
                people[i][1] = people[i][24]
                people[i][28] = 0

        infectionresult[1][j] = infectingPeople(people, population)# infected
        if peak < infectionresult[1][j] :
            peak = infectionresult[1][j]
            peaktime = j

        #print j, ": ", infectionresult[1][j]
        infectedtemp += infectionresult[1][j]
        exposedtemp += infectionresult[0][j]
        peopleH += peopletoHospi[j]

        if number != 8:
            if gf == 0 and infectedtemp > population/25 :
                gf = 1
                gt = 0
                print "flag is raised at", j

            if gf == 1:
                gt += 1
                if gt == delay[0]:
                    print gt
                    measure2(people, population, length, 2)
                if gt == delay[1]:
                    print gt
                    measure1(people, population, length, 1)
                if gt == delay[2]:
                    print gt
                    measure0(people, population, length, 0)
                #if gt == delay:
                #    vaccinated = vaccinate(people, population, prob)
                #    over = 1

        temparray = recoveringPeople(people, people1 + people2)
        recoveryresult[0][j] = temparray[0] #recovered
        recoveryresult[1][j] = temparray[1] #removed
        recoveredtemp += recoveryresult[0][j]
        removedtemp += recoveryresult[1][j]

    infectionresult[1][0] = 50
    infectedtemp += infectionresult[1][0]

    doplot(plottype, recoveryresult, infectionresult, totalTime, number)
    economyimpact = (1 * levels[0]) + (2 * levels[1]) + (3 * levels[2])


    print "After all iterations, number of people of each awareness level: ", alcount
    print "After all iterations, number of exposed people: ",exposedtemp
    print "After all iterations, number of infected people: ",infectedtemp
    print "peak: ", peak, "peaktime: ", peaktime
    print "After all iterations, number of infected people of each awareness level: ",levels
    print "After all iterations, number of succeptibility lowered people: ", lowered
    print "The economic impact caused is: ", economyimpact
    if number != 8:
        print "The cost is: ", calculatecost()
    print "After all iterations, number of recovered people: ", recoveredtemp
    print "number of people went to market: ", peopleinmarket
    print "number of people went to hospitals: ", peopleH
    #print "After all iterations, number of succeptibility lowered people: ", takencare
    #print "After all iterations, number of vaccinated people: ", vaccinated
    #print "After all iterations, number of removed people: ",removedtemp

    #pl.show()

